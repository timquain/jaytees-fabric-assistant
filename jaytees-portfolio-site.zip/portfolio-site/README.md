# JayTees Fabric Assistant — Portfolio Site

A single-page case study describing how I designed and built **JayTees Fabric Assistant**, an AI-powered e‑commerce chatbot.

## 🚀 Quick Start (local preview)
Just open `index.html` in your browser.

## 🌐 Publish on GitHub Pages (free)
1. Create a new GitHub repo (e.g., `jaytees-fabric-assistant`).
2. Upload these files (drag-and-drop in GitHub UI or push via git).
3. Go to **Settings → Pages**.
4. Under **Build and deployment**, set:
   - **Source:** *Deploy from a branch*
   - **Branch:** `main` (or `master`) / root
5. Click **Save**. Wait ~1 minute.
6. Your site will be live at: `https://<your-username>.github.io/<repo-name>/`

> Tip: `.nojekyll` is included to avoid Jekyll processing.

## 🌐 Publish on Netlify (drag & drop)
1. Go to https://app.netlify.com/drop
2. Drag the entire folder onto the page.
3. Netlify deploys and gives you a public URL instantly.
4. Optionally set a custom site name and domain.

## 🖼️ Add screenshots
Put images into `assets/` and update the placeholders in `index.html`:
```html
<img src="assets/docs-screenshot.png" alt="API docs" />
<img src="assets/demo-chat.png" alt="Chat UI" />
<img src="assets/passing-tests.png" alt="Tests passed" />
```

## 🔗 Suggested links to add
- Runbook PDF or DOCX (setup & verification)
- GitHub repository for the chatbot code
- Live demo link (if hosting the API + /demo)

## 📄 License
MIT — see `LICENSE`.
