Place your screenshots in this folder and reference them from index.html, e.g.:
  <img src="assets/docs-screenshot.png" alt="API docs">
Suggested images:
  - docs-screenshot.png   (Swagger /docs page)
  - demo-chat.png         (/demo chat UI)
  - passing-tests.png     (Terminal summary 4/4 passed)
